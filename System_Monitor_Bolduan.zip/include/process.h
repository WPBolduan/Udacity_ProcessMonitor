#ifndef PROCESS_H
#define PROCESS_H

#include <string>
/*
Basic class for Process representation
It contains relevant attributes as shown below
*/
class Process {
 public:
  int Pid() const;                               // See src/process.cpp
  std::string User() const;                      // See src/process.cpp
  std::string Command() const;                   // See src/process.cpp
  float CpuUtilization() const;                  // See src/process.cpp
  std::string Ram() const;                       // See src/process.cpp
  int getRam() const;
  long int UpTime() const;                       // See src/process.cpp
  bool operator<(Process const& a) const;        // See src/process.cpp
  Process (int pid);                             // Will be used in system.cpp to create process instance and "fill" the processes vector



  // private member variables

 private:
 int my_pid_;
 long my_ram_, my_uptime_;
 std::string my_user_, my_command_;
 float my_utilization_;
};
#endif