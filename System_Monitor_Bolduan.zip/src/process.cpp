#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h"
#include "linux_parser.h"

using std::string;
using std::to_string;
using std::vector;

// chosing here the way to not just pass through but store the processes in object instances
Process::Process(int pid) {
  my_pid_ = pid;
  my_command_ = LinuxParser::Command(pid);
  my_ram_ = std::stol(LinuxParser::Ram(pid));
  my_uptime_ = LinuxParser::UpTime(pid);
  my_user_ = LinuxParser::User(pid);

  // got this one with help from mentor forum

  long seconds = LinuxParser::UpTime() - my_uptime_;
  long totaltime = LinuxParser::ActiveJiffies(pid);
  try {
    my_utilization_ = float(totaltime) / float(seconds);

  } catch (...) {
    my_utilization_ = 0;
  }
}

// Return this process's ID
int Process::Pid() const { return my_pid_; }

// Return this process's CPU utilization
float Process::CpuUtilization() const { return my_utilization_; }

// Return the command that generated this process
string Process::Command() const { return my_command_; }

// Return this process's memory utilization
string Process::Ram() const { return std::to_string(my_ram_); }

int Process::getRam() const { return my_ram_; }

// Return the user (name) that generated this process
string Process::User() const { return my_user_; }

//  Return the age of this process (in seconds)
long int Process::UpTime() const { return my_uptime_; }
// Overload the "less than" comparison operator for Process objects
// https://knowledge.udacity.com/questions/96882

bool Process::operator<(Process const& a) const {
  return CpuUtilization() < a.CpuUtilization();
}